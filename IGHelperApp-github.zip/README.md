# IGHelper — Instagram Reels Auto Like + Save (Android APK)

Auto-like, auto-save, at auto-scroll sa Instagram Reels gamit ang **Accessibility Service** — may floating control panel na pwedeng i-drag at i-collapse.

> **Paalala:** Personal automation tool ito para sa sariling account at sariling device. Hindi affiliated sa Instagram/Meta. Maaaring makaapekto ang automation sa Instagram ToS — gamitin ang sariling kapahamakan, panatilihin ang mababang limits.

## Features

- **Floating panel sa loob ng Instagram** — awtomatikong lilitaw kapag bukas ang Instagram at nawawala kapag lumabas; i-drag ang header para ilipat, i-tap ang header para i-collapse, ✕ para patayin, ⚙ para buksan ang settings
- **Auto Like** — double-tap sa Reel (may random jitter para hindi robotic ang galaw)
- **Auto Save** — hinahanap ang Save/Bookmark button sa accessibility tree (may fallback na tap)
- **Auto Scroll** — swipe papunta sa susunod na Reel
- **Daily limits** — default: 20 likes + 7 saves kada araw, random delay 4–9s kada Reel
- **Live counters** — Like X/20 · Save X/7 (nire-reset araw-araw)
- **Switches** — pwedeng i-on/off ang Like, Save, o Scroll individually (sa app o sa floating panel)

## Paano i-install sa phone

1. I-download ang `IGHelper.apk` (o ang release APK sa GitHub Releases).
2. Sa phone: **Settings → Apps → Special access → Install unknown apps** → payagan ang file manager/browser na mag-install.
3. I-tap ang APK para i-install → buksan ang **IG Helper**.
4. Pindutin ang **"1. Enable Accessibility Service"** → hanapin ang **IG Helper** → ON.
5. Pindutin ang **"2. Start"** → buksan ang **Instagram Reels** — kusang magla-like at mag-se-save ayon sa limits. Lilitaw ang **floating panel** (Start/Stop, toggles, counters) sa loob mismo ng IG.

## Mga setting (MainActivity)

| Setting | Default | Kahulugan |
|---|---|---|
| Daily like limit | 20 | Kasunod na like bago huminto |
| Daily save limit | 7 | Kasunod na save bago huminto |
| Min / Max wait | 4s / 9s | Random na hinta bawat Reel |
| Like / Save / Scroll | ON | Toggle kada aksyon |

## Paano i-build galing sa source

**Gamit ang Android Studio:** i-open ang folder → **Build → Build Project** → APK nasa `app/build/outputs/apk/debug/`.

**Gamit ang CLI** (kailangan: JDK 17 + Android SDK Platform 34 + Build-Tools 34.0.0):

```bash
./gradlew assembleDebug     # debug APK (auto-signed)
./gradlew assembleRelease   # release APK (kailangan ng keystore, tingnan sa baba)
```

### Release signing (opsyonal)

Gumawa ng keystore at `app/keystore.properties` (hindi kasama sa git):

```properties
storeFile=../keystore/ighelper-release.jks
storePassword=<password>
keyAlias=ighelper
keyPassword=<password>
```

Kung wala ito, `assembleRelease` ay gagawa ng unsigned APK pa rin.

## Struktur ng project

```
IGHelperApp/
├── app/src/main/java/com/example/ighelper/
│   ├── MainActivity.kt      # UI: limits, switches, status
│   └── AutoService.kt       # Accessibility service: gestures + overlay
├── app/src/main/res/        # strings, accessibility config, launcher icon
├── app/build.gradle         # SDK 34, signing config
└── gradle/wrapper/          # Gradle 8.7
```

## Paano gumagana

1. Kapag ON ang Accessibility Service, nagre-render ang floating overlay (`TYPE_ACCESSIBILITY_OVERLAY`).
2. Bawat cycle: double-tap (like) → hanapin at pindutin ang Save button → swipe up (scroll) → random hinta.
3. Ang mga counter ay naka-`SharedPreferences` at nire-reset kapag nagbago ang petsa.

## License / Disclaimer

Para sa personal na gamit. Ginagamit ang Instagram app ng user sa sariling device — ikaw ang responsable sa anumang epekto sa account. `com.instagram.android` ay rehistradong trademark ng Meta.
